$(document).ready(function(){
	var preventAction = true,
		dropdown = $(".dropdown"),
		dropdownDefinitionList = dropdown.children('.dropdown__definition-list'),
		dropdownDefinition = dropdownDefinitionList.find('.dropdown__definition');

	$(".nav__link--dropdown").on('click', function(){
		dropdown.slideToggle(180);
	});

	dropdownDefinitionList.on("click", function(event){
		// preventAction = true;
		// if(preventAction){
			// event.preventDefault();
		// };
		dropdownDefinition.css('display','none');
		$(this).children(dropdownDefinition).css('display','block');
	});

	$('.dropdown__link').on('click', function(){
		//disable event.preventDefault() which was created on higher level
		// preventAction = false;
	});
});







// window.preventAction = true;

// $(document).keypress(function(e){
// 	if(e.keyCode==40 || e.keyCode==38){
// 		if (window.preventAction) e.preventDefault();
// 	};

// 	$('#img2').click(function(e){
// 		window.preventAction = false;
// 	});

// }